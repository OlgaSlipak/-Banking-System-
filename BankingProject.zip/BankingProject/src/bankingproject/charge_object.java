package bankingproject;

public class charge_object {

    private int Id_client;

    private int Number_account;

    private String Type_account;

    private double Balance;

    private double Limit_account;

    private String Type_penalties;

    private double Amount_penalties;

    private String Type_charge;

    private double Amount_charge;

    private String Type_commission;

    private double Amount_commission;

    public charge_object(int Id_client, int Number_account, String Type_account, double Balance, double Limit_account, String Type_penalties, double Amount_penalties, String Type_charge, double Amount_charge, String Type_commission, double Amount_commission) {
        this.Id_client = Id_client;
        this.Number_account = Number_account;
        this.Type_account = Type_account;
        this.Balance = Balance;
        this.Limit_account = Limit_account;
        this.Type_penalties = Type_penalties;
        this.Amount_penalties = Amount_penalties;
        this.Type_charge = Type_charge;
        this.Amount_charge = Amount_charge;
        this.Type_commission = Type_commission;
        this.Amount_commission = Amount_commission;
    }

    public charge_object() {
        this.Id_client = 0;
        this.Number_account = 0;
        this.Type_account = "";
        this.Balance = 0;
        this.Limit_account = 0;
        this.Type_penalties = "";
        this.Amount_penalties = 0;
        this.Type_charge = "";
        this.Amount_charge = 0;
        this.Type_commission = "";
        this.Amount_commission = 0;
    }

    public int getId_client() {
        return Id_client;
    }

    public int getNumber_account() {
        return Number_account;
    }

    public String getType_account() {
        return Type_account;
    }

    public double getBalance() {
        return Balance;
    }

    public double getLimit_account() {
        return Limit_account;
    }

    public String getType_penalties() {
        return Type_penalties;
    }

    public String getType_charge() {
        return Type_charge;
    }

    public double getAmount_charge() {
        return Amount_charge;
    }

    public String getType_commission() {
        return Type_commission;
    }

    public double getAmount_commission() {
        return Amount_commission;
    }

    public void setId_client(int Id_client) {
        this.Id_client = Id_client;
    }

    public void setNumber_account(int Number_account) {
        this.Number_account = Number_account;
    }

    public void setType_account(String Type_account) {
        this.Type_account = Type_account;
    }

    public void setBalance(double Balance) {
        this.Balance = Balance;
    }

    public void setLimit_account(double Limit_account) {
        this.Limit_account = Limit_account;
    }

    public void setType_penalties(String Type_penalties) {
        this.Type_penalties = Type_penalties;
    }

    public void setAmount_penalties(double Amount_penalties) {
        this.Amount_penalties = Amount_penalties;
    }

    public void setType_charge(String Type_charge) {
        this.Type_charge = Type_charge;
    }

    public void setAmount_charge(double Amount_charge) {
        this.Amount_charge = Amount_charge;
    }

    public void setType_commission(String Type_commission) {
        this.Type_commission = Type_commission;
    }

    public void setAmount_commission(double Amount_commission) {
        this.Amount_commission = Amount_commission;
    }
}
