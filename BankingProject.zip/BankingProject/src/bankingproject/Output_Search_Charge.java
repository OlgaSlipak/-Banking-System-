package bankingproject;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class Output_Search_Charge implements ActionListener {

    JTextField client_idTF, number_accountTF, b_Type_accountTF, b_Limit_accountTF, b_Type_chargeTF, b_Amount_chargeTF;

    charge_object info_charge_obj;

    public Output_Search_Charge() {
        JFrame chargeOutputframe1 = new JFrame();
        JLabel client_idL = new JLabel("Client ID:", SwingConstants.RIGHT);
        JLabel number_accountL = new JLabel("Number Account:", SwingConstants.RIGHT);
        JLabel b_Type_accountL = new JLabel("Type Account:", SwingConstants.RIGHT);
        JLabel b_Limit_accountL = new JLabel("Limit Account:", SwingConstants.RIGHT);
        JLabel b_Type_chargeL = new JLabel("Type Charge:", SwingConstants.RIGHT);
        JLabel b_Amount_chargeL = new JLabel("Amount Charge:", SwingConstants.RIGHT);
        client_idTF = new JTextField(10);
        number_accountTF = new JTextField(10);
        b_Type_accountTF = new JTextField(10);
        b_Limit_accountTF = new JTextField(10);
        b_Type_chargeTF = new JTextField(10);
        b_Amount_chargeTF = new JTextField(10);
        JButton exitB = new JButton("Exit");
        exitB.addActionListener(this);
        chargeOutputframe1.setTitle("RESULT OF SEARCHING");
        Container pane = chargeOutputframe1.getContentPane();
        pane.setLayout(new GridLayout(7, 2));
        pane.add(client_idL);
        pane.add(client_idTF);
        pane.add(number_accountL);
        pane.add(number_accountTF);
        pane.add(b_Type_accountL);
        pane.add(b_Type_accountTF);
        pane.add(b_Limit_accountL);
        pane.add(b_Limit_accountTF);
        pane.add(b_Type_chargeL);
        pane.add(b_Type_chargeTF);
        pane.add(b_Amount_chargeL);
        pane.add(b_Amount_chargeTF);
        pane.add(exitB);
        chargeOutputframe1.setSize(800, 400);
        chargeOutputframe1.setVisible(true);
    }

    public void actionPerformed(ActionEvent b) {
        if (b.getActionCommand().equals("Exit")) {
            System.exit(0);
        }
    }
}
