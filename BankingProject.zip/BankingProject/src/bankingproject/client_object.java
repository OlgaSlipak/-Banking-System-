package bankingproject;

public class client_object {

    private int Id_client;

    private String Fname;

    private String Lname;

    private String Address;

    private String Tel;

    private String E_mail;

    private int SSN;

    private String Status;

    public client_object() {
        this.Id_client = 0;
        this.Fname = "";
        this.Lname = "";
        this.Address = "";
        this.Tel = "";
        this.E_mail = "";
        this.SSN = 0;
        this.Status = "";
    }

    public client_object(int Id_client, String Fname, String Lname, String Address, String Tel, String E_mail, int SSN, String Status) {
        this.Id_client = Id_client;
        this.Fname = Fname;
        this.Lname = Lname;
        this.Address = Address;
        this.Tel = Tel;
        this.E_mail = E_mail;
        this.SSN = SSN;
        this.Status = Status;
    }

    public int getId_client() {
        return Id_client;
    }

    public String getFname() {
        return Fname;
    }

    public String getLname() {
        return Lname;
    }

    public String getAddress() {
        return Address;
    }

    public String getTel() {
        return Tel;
    }

    public void setStatus(String Status) {
        this.Status = Status;
    }

    public String getE_mail() {
        return E_mail;
    }

    public String getStatus() {
        return Status;
    }

    public int getSSN() {
        return SSN;
    }

    public void setId_client(int Id_client) {
        this.Id_client = Id_client;
    }

    public void setFname(String Fname) {
        this.Fname = Fname;
    }

    public void setLname(String Lname) {
        this.Lname = Lname;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }

    public void setTel(String Tel) {
        this.Tel = Tel;
    }

    public void setE_mail(String E_mail) {
        this.E_mail = E_mail;
    }

    public void setSSN(int SSN) {
        this.SSN = SSN;
    }
}
