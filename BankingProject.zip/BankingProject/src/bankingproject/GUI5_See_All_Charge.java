package bankingproject;

import static bankingproject.BankingGInterfaceCharge.info_charge_obj;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class GUI5_See_All_Charge {

    String Type_charge, Desc_charge, Period_calc_charge, Day_pay_charge;

    double Rate_charge;

    JTextField TF1TF, TF2TF, TF3TF, TF4TF, TF5TF, TF6TF, TF7TF, TF8TF, TF9TF, TF10TF, TF11TF, TF12TF, TF13TF, TF14TF, TF15TF, TF16TF, TF17TF, TF18TF, TF19TF, TF20TF;

    double amount_charge;

    public GUI5_See_All_Charge() {
        JFrame chargeOutputframe5 = new JFrame();
        JLabel l1L = new JLabel("TYPE CHARGE", SwingConstants.LEFT);
        JLabel L2L = new JLabel("DESCRIPTION OF CHERGE", SwingConstants.LEFT);
        JLabel L3L = new JLabel("RATE CHARGE", SwingConstants.LEFT);
        JLabel L4L = new JLabel("PERIOD FOR CALCULATION CHARGE", SwingConstants.LEFT);
        JLabel L5L = new JLabel("DAY PAY CHARGE", SwingConstants.LEFT);
        TF1TF = new JTextField(50);
        TF2TF = new JTextField(20);
        TF3TF = new JTextField(10);
        TF4TF = new JTextField(10);
        TF5TF = new JTextField(10);
        TF6TF = new JTextField(10);
        TF7TF = new JTextField(10);
        TF8TF = new JTextField(10);
        TF9TF = new JTextField(10);
        TF10TF = new JTextField(10);
        TF11TF = new JTextField(10);
        TF12TF = new JTextField(10);
        TF13TF = new JTextField(10);
        TF14TF = new JTextField(10);
        TF15TF = new JTextField(10);
        TF16TF = new JTextField(10);
        TF17TF = new JTextField(10);
        TF18TF = new JTextField(10);
        TF19TF = new JTextField(10);
        TF20TF = new JTextField(10);
        chargeOutputframe5.setTitle("INFORMATION ABOUT TYPE CHARGE FROM DATABASE");
        Container pane = chargeOutputframe5.getContentPane();
        pane.setLayout(new GridLayout(5, 5));
        pane.add(l1L);
        pane.add(L2L);
        pane.add(L3L);
        pane.add(L4L);
        pane.add(L5L);
        pane.add(TF1TF);
        pane.add(TF2TF);
        pane.add(TF3TF);
        pane.add(TF4TF);
        pane.add(TF5TF);
        pane.add(TF6TF);
        pane.add(TF7TF);
        pane.add(TF8TF);
        pane.add(TF9TF);
        pane.add(TF10TF);
        pane.add(TF11TF);
        pane.add(TF12TF);
        pane.add(TF13TF);
        pane.add(TF14TF);
        pane.add(TF15TF);
        pane.add(TF16TF);
        pane.add(TF17TF);
        pane.add(TF18TF);
        pane.add(TF19TF);
        pane.add(TF20TF);
        chargeOutputframe5.setSize(1700, 450);
        chargeOutputframe5.setVisible(true);
        ConnectJavaOracle.openOracleConnection("scott", "tiger");
        String query;
        query = "Select ";
        query = query + "Type_charge, Desc_charge, Rate_charge, Period_calc_charge, Day_pay_charge";
        query = query + " from Charge_type_insurance ";
        query = query + "where Type_charge = 'CIP4000'";
        System.out.println("query: " + query);
        ConnectJavaOracle.rs = ConnectJavaOracle.processSearchQuery(query);
        try {
            while (ConnectJavaOracle.rs.next()) {
                Type_charge = ConnectJavaOracle.rs.getString("Type_charge");
                TF1TF.setText(Type_charge);
                Desc_charge = ConnectJavaOracle.rs.getString("Desc_charge");
                TF2TF.setText(Desc_charge);
                Rate_charge = ConnectJavaOracle.rs.getDouble("Rate_charge");
                TF3TF.setText("" + Rate_charge);
                Period_calc_charge = ConnectJavaOracle.rs.getString("Period_calc_charge");
                TF4TF.setText(Period_calc_charge);
                Day_pay_charge = ConnectJavaOracle.rs.getString("Day_pay_charge");
                TF5TF.setText(Day_pay_charge);
            }
        } catch (Exception e) {
            System.out.println("Error Search- " + e);
        }
        query = "Select ";
        query = query + "Type_charge, Desc_charge, Rate_charge, Period_calc_charge, Day_pay_charge";
        query = query + " from Charge_type_insurance ";
        query = query + "where  Type_charge = 'CIPL4000' ";
        System.out.println("query: " + query);
        ConnectJavaOracle.rs = ConnectJavaOracle.processSearchQuery(query);
        try {
            while (ConnectJavaOracle.rs.next()) {
                Type_charge = ConnectJavaOracle.rs.getString("Type_charge");
                TF6TF.setText(Type_charge);
                Desc_charge = ConnectJavaOracle.rs.getString("Desc_charge");
                TF7TF.setText(Desc_charge);
                Rate_charge = ConnectJavaOracle.rs.getDouble("Rate_charge");
                TF8TF.setText("" + Rate_charge);
                Period_calc_charge = ConnectJavaOracle.rs.getString("Period_calc_charge");
                TF9TF.setText(Period_calc_charge);
                Day_pay_charge = ConnectJavaOracle.rs.getString("Day_pay_charge");
                TF10TF.setText(Day_pay_charge);
            }
        } catch (Exception e) {
            System.out.println("Error Search- " + e);
        }
        query = "Select ";
        query = query + "Type_charge, Desc_charge, Rate_charge, Period_calc_charge, Day_pay_charge";
        query = query + " from Charge_type_insurance ";
        query = query + "where Type_charge = 'CIC4000'";
        System.out.println("query: " + query);
        ConnectJavaOracle.rs = ConnectJavaOracle.processSearchQuery(query);
        try {
            while (ConnectJavaOracle.rs.next()) {
                Type_charge = ConnectJavaOracle.rs.getString("Type_charge");
                TF11TF.setText(Type_charge);
                Desc_charge = ConnectJavaOracle.rs.getString("Desc_charge");
                TF12TF.setText(Desc_charge);
                Rate_charge = ConnectJavaOracle.rs.getDouble("Rate_charge");
                TF13TF.setText("" + Rate_charge);
                Period_calc_charge = ConnectJavaOracle.rs.getString("Period_calc_charge");
                TF14TF.setText(Period_calc_charge);
                Day_pay_charge = ConnectJavaOracle.rs.getString("Day_pay_charge");
                TF15TF.setText(Day_pay_charge);
            }
        } catch (Exception e) {
            System.out.println("Error Search- " + e);
        }
        query = "Select ";
        query = query + "Type_charge, Desc_charge, Rate_charge, Period_calc_charge, Day_pay_charge";
        query = query + " from Charge_type_insurance ";
        query = query + "where Type_charge = 'CIC0'";
        System.out.println("query: " + query);
        ConnectJavaOracle.rs = ConnectJavaOracle.processSearchQuery(query);
        try {
            while (ConnectJavaOracle.rs.next()) {
                Type_charge = ConnectJavaOracle.rs.getString("Type_charge");
                TF16TF.setText(Type_charge);
                Desc_charge = ConnectJavaOracle.rs.getString("Desc_charge");
                TF17TF.setText(Desc_charge);
                Rate_charge = ConnectJavaOracle.rs.getDouble("Rate_charge");
                TF18TF.setText("" + Rate_charge);
                Period_calc_charge = ConnectJavaOracle.rs.getString("Period_calc_charge");
                TF19TF.setText(Period_calc_charge);
                Day_pay_charge = ConnectJavaOracle.rs.getString("Day_pay_charge");
                TF20TF.setText(Day_pay_charge);
            }
        } catch (Exception e) {
            System.out.println("Error Search- " + e);
        }
    }
}
