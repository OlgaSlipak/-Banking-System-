package bankingproject;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class GUI3_Delete_charge implements ActionListener {

    JTextField client_id3TF, number_account3TF;

    public GUI3_Delete_charge() {
        JFrame chargeOutputframe3 = new JFrame();
        JLabel client_idL = new JLabel("Client ID:", SwingConstants.RIGHT);
        JLabel number_accountL = new JLabel("Number Account:", SwingConstants.RIGHT);
        client_id3TF = new JTextField(10);
        number_account3TF = new JTextField(10);
        JButton exitB = new JButton("Exit");
        exitB.addActionListener(this);
        JButton deleteB = new JButton("DELETE EXESTING CHARGE");
        deleteB.addActionListener(this);
        chargeOutputframe3.setTitle("DELETE EXESTING CHARGE");
        Container pane = chargeOutputframe3.getContentPane();
        pane.setLayout(new GridLayout(3, 2));
        pane.add(client_idL);
        pane.add(client_id3TF);
        pane.add(number_accountL);
        pane.add(number_account3TF);
        pane.add(deleteB);
        pane.add(exitB);
        chargeOutputframe3.setSize(800, 400);
        chargeOutputframe3.setVisible(true);
    }

    public void actionPerformed(ActionEvent a) {
        if (a.getActionCommand().equals("Exit")) {
            System.exit(0);
        } else if (a.getActionCommand().equals("DELETE EXESTING CHARGE")) {
            ConnectJavaOracle.openOracleConnection("scott", "tiger");
            String query;
            query = "DELETE FROM Account_entity ";
            query = query + "where Id_client = ";
            query = query + Integer.parseInt(client_id3TF.getText()) + " and Number_account = " + Integer.parseInt(number_account3TF.getText());
            System.out.println("query: " + query);
            JOptionPane.showMessageDialog(null, "Banking Information " + "You deleted successfully!", "Banking Information", JOptionPane.INFORMATION_MESSAGE);
            ConnectJavaOracle.processQuery(query);
        }
    }
}
