package bankingproject;

import static bankingproject.BankingGInterfaceCharge.info_charge_obj;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class BankingGInterfaceClientAp extends JFrame implements ActionListener, ListSelectionListener, ItemListener {

    static client_object NewClient = new client_object();

    int clientId;

    int Id_client;

    String Fname;

    String Lname;

    String Address;

    String Tel;

    String E_mail;

    int SSN;

    String Status;

    int Id_clientR;

    String FnameR;

    String LnameR;

    int Number_accountR;

    String Type_accountR;

    String Desc_accountR;

    int BalanceR;

    int Limit_accountR;

    JTextArea whiteBoardTA = new JTextArea(70, 80);

    JMenuItem searchI = new JMenuItem("Search for client");

    JMenuItem updateI = new JMenuItem("Update info client");

    JMenuItem insertI = new JMenuItem("Insert new client");

    JMenuItem deleteI = new JMenuItem("Delete client");

    JMenuItem reportsI = new JMenuItem("Reports for client");

    JMenuItem exitI = new JMenuItem("Exit");

    private BorderLayout BorderLayoutMgr;

    public BankingGInterfaceClientAp() {
        this.setTitle("CLIENT APPLICATION");
        Container pane = getContentPane();
        setSize(900, 900);
        BorderLayoutMgr = new BorderLayout(5, 5);
        JMenuBar menuBR = new JMenuBar();
        this.setJMenuBar(menuBR);
        JMenu searchM = new JMenu("Search for client");
        JMenu updateM = new JMenu("Update info client");
        JMenu insertM = new JMenu("Insert new client");
        JMenu deleteM = new JMenu("Delete client");
        JMenu reportsM = new JMenu("Reports for client");
        JMenu exitM = new JMenu("Exit");
        menuBR.add(searchM);
        menuBR.add(updateM);
        menuBR.add(insertM);
        menuBR.add(deleteM);
        menuBR.add(reportsM);
        menuBR.add(exitM);
        searchM.add(searchI);
        searchI.addActionListener(this);
        updateM.add(updateI);
        updateI.addActionListener(this);
        insertM.add(insertI);
        insertI.addActionListener(this);
        deleteM.add(deleteI);
        deleteI.addActionListener(this);
        reportsM.add(reportsI);
        reportsI.addActionListener(this);
        exitM.add(exitI);
        exitI.addActionListener(this);
        pane.setLayout(BorderLayoutMgr);
        pane.add(whiteBoardTA, BorderLayout.CENTER);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == searchI) {
            String clientId_str;
            clientId_str = JOptionPane.showInputDialog(null, "\nPlease, enter your client Id and press OK", "Input", JOptionPane.QUESTION_MESSAGE);
            clientId = Integer.parseInt(clientId_str);
            NewClient.setId_client(clientId);
            whiteBoardTA.append("\n\nYOU ARE SEACHING INFORMATION FOR ClientId: " + NewClient.getId_client());
            ConnectJavaOracle.openOracleConnection("scott", "tiger");
            String query;
            query = "Select ";
            query = query + "Id_client, Fname, Lname, Address, Tel, E_mail, SSN, Status";
            query = query + " from client_entity ";
            query = query + "where Id_client = ";
            query = query + clientId;
            System.out.println("query: " + query);
            ConnectJavaOracle.rs = ConnectJavaOracle.processSearchQuery(query);
            try {
                if (ConnectJavaOracle.rs.next() == false) {
                    JOptionPane.showMessageDialog(null, "Banking Exception " + " Check please ID client! doesn't exist", "Banking Exception", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    Id_client = ConnectJavaOracle.rs.getInt("Id_client");
                    NewClient.setId_client(Id_client);
                    Fname = ConnectJavaOracle.rs.getString("Fname");
                    NewClient.setFname(Fname);
                    Lname = ConnectJavaOracle.rs.getString("Lname");
                    NewClient.setLname(Lname);
                    Address = ConnectJavaOracle.rs.getString("Address");
                    NewClient.setAddress(Address);
                    Tel = ConnectJavaOracle.rs.getString("Tel");
                    NewClient.setTel(Tel);
                    E_mail = ConnectJavaOracle.rs.getString("E_mail");
                    NewClient.setE_mail(E_mail);
                    SSN = ConnectJavaOracle.rs.getInt("SSN");
                    NewClient.setSSN(SSN);
                    Status = ConnectJavaOracle.rs.getString("Status");
                    NewClient.setStatus(Status);
                    whiteBoardTA.append("\n\nCliend Id: " + NewClient.getId_client() + "\nFirst name of client: " + NewClient.getFname() + "\nLast name of client: " + NewClient.getLname() + "\nAddress of client: " + NewClient.getAddress() + "\nTelephone of client " + NewClient.getTel() + "\nE_mail of client: " + NewClient.getE_mail() + "\nSSN of client: " + NewClient.getSSN() + "\nStatus of client: " + NewClient.getStatus());
                }
            } catch (Exception o) {
                System.out.println("Error Search- " + o);
            }
        }
        if (e.getSource() == exitI) {
            System.exit(0);
        }
        if (e.getSource() == deleteI) {
            GUI6_Delete_client delete_client = new GUI6_Delete_client();
        }
        if (e.getSource() == updateI) {
            GUI7_Update_client update_client = new GUI7_Update_client();
        }
        if (e.getSource() == insertI) {
            GUI8_Insert_client insert_client = new GUI8_Insert_client();
        }
        if (e.getSource() == reportsI) {
            String output = "";
            String clientId_str;
            clientId_str = JOptionPane.showInputDialog(null, "\nPlease, enter your client Id and press OK", "Id Client for report", JOptionPane.QUESTION_MESSAGE);
            clientId = Integer.parseInt(clientId_str);
            ConnectJavaOracle.openOracleConnection("scott", "tiger");
            String query;
            query = "Select ";
            query = query + "client_entity.Id_client, client_entity.Fname, client_entity.Lname,";
            query = query + " Account_entity.Number_account, Account_entity.Type_account, Account_type.Desc_account,";
            query = query + " Account_entity.Balance, Account_entity.Limit_account ";
            query = query + "from client_entity, Account_entity, Account_type ";
            query = query + "where client_entity.Id_client = Account_entity.Id_client and Account_entity.Number_account = Account_type.Number_account and client_entity.Id_client = ";
            query = query + clientId;
            System.out.println("query: " + query);
            ConnectJavaOracle.rs = ConnectJavaOracle.processSearchQuery(query);
            output += "Report for Cliend Id: " + clientId + "\n\n";
            try {
                while (ConnectJavaOracle.rs.next()) {
                    Id_clientR = ConnectJavaOracle.rs.getInt("Id_client");
                    FnameR = ConnectJavaOracle.rs.getString("Fname");
                    LnameR = ConnectJavaOracle.rs.getString("Lname");
                    Number_accountR = ConnectJavaOracle.rs.getInt("Number_account");
                    Type_accountR = ConnectJavaOracle.rs.getString("Type_account");
                    Desc_accountR = ConnectJavaOracle.rs.getString("Desc_account");
                    BalanceR = ConnectJavaOracle.rs.getInt("Balance");
                    Limit_accountR = ConnectJavaOracle.rs.getInt("Limit_account");
                    output += "\nFirst Name: " + FnameR + "\nLast Name: " + LnameR + "\nNumber Account: " + Number_accountR + "\nAccount Type: " + Type_accountR + "\nDescription Account: " + Desc_accountR + "\nBalance: " + BalanceR + "\nLimit of Account: " + Limit_accountR + "\n\n";
                }
                if (clientId < 0 || clientId > 8) {
                    JOptionPane.showMessageDialog(null, "Banking Exception " + "You entered wrong input. Check please ID client!", "Banking Exception", JOptionPane.INFORMATION_MESSAGE);
                } else
                    JOptionPane.showMessageDialog(null, output, "Client Report", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception o) {
                System.out.println("Error Search- " + o);
            }
        }
    }

    @Override
    public void valueChanged(ListSelectionEvent e) {
    }

    @Override
    public void itemStateChanged(ItemEvent e) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
