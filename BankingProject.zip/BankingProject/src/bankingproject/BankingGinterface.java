package bankingproject;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class BankingGinterface implements ActionListener {

    public BankingGinterface() {
        JFrame wframe = new JFrame();
        JLabel client_idL = new JLabel("WELCOME TO THE BANKING APPLICATION OF VSB BANK!", SwingConstants.CENTER);
        JButton chargeB = new JButton("Charge Application");
        chargeB.addActionListener(this);
        JButton commissionB = new JButton("Commisssion Application");
        commissionB.addActionListener(this);
        JButton penaltiesB = new JButton("Penalties Application");
        penaltiesB.addActionListener(this);
        JButton client_infoB = new JButton("Client Application");
        client_infoB.addActionListener(this);
        JButton account_infoB = new JButton("Account Application");
        account_infoB.addActionListener(this);
        JButton exitB = new JButton("Exit");
        exitB.addActionListener(this);
        wframe.setTitle("Main Banking Application VSB BANK");
        Container pane = wframe.getContentPane();
        pane.setLayout(new GridLayout(7, 1));
        pane.add(client_idL);
        pane.add(chargeB);
        pane.add(commissionB);
        pane.add(penaltiesB);
        pane.add(client_infoB);
        pane.add(account_infoB);
        pane.add(exitB);
        wframe.setSize(400, 800);
        wframe.setVisible(true);
    }

    public void actionPerformed(ActionEvent b) {
        if (b.getActionCommand().equals("Exit")) {
            System.exit(0);
        }
        if (b.getActionCommand().equals("Charge Application")) {
            BankingGInterfaceCharge myInterfaceCharge = new BankingGInterfaceCharge();
        }
        if (b.getActionCommand().equals("Client Application")) {
            BankingGInterfaceClientAp myInterfaceClient = new BankingGInterfaceClientAp();
        }
        if (b.getActionCommand().equals("Commisssion Application")) {
            new COMMISSIONJFrame().setVisible(true);
        }
        if (b.getActionCommand().equals("Penalties Application")) {
            JOptionPane.showMessageDialog(null, "Banking Information " + "Application is developing. Please test Charge Application, Client Application, Commission Application", "Banking Information", JOptionPane.INFORMATION_MESSAGE);
        }
        if (b.getActionCommand().equals("Account Application")) {
            JOptionPane.showMessageDialog(null, "Banking Information " + "Application is developing. Please test Charge Application, Client Application, Commission Application", "Banking Information", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}
