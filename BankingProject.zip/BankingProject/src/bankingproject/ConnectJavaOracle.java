package bankingproject;

import java.sql.*;

public class ConnectJavaOracle {

    static Statement s;

    static Connection c;

    static ResultSet rs;

    public static void openOracleConnection(String username, String password) {
        c = null;
        try {
            System.out.println("********************************");
            System.out.println("* Loading the driver *");
            Class.forName("oracle.jdbc.driver.OracleDriver");
            String url = "jdbc:oracle:thin:@localhost:1521:orcl";
            c = DriverManager.getConnection(url, username, password);
            s = c.createStatement();
        } catch (Exception e) {
            try {
                c.rollback();
            } catch (Exception ee) {
                System.out.println("Error!");
            }
            System.out.println("Error - Database Management for tables():" + e);
        }
    }

    public static void processQuery(String query) {
        try {
            System.out.println("*****************PROCESS************");
            s.executeUpdate(query);
        } catch (Exception e) {
            try {
                c.rollback();
            } catch (Exception ee) {
                System.out.println("Error!");
            }
            System.out.println("Error - Database Management for tables():" + e);
        }
    }

    public static ResultSet processSearchQuery(String query) {
        try {
            System.out.println("*****************PROCESS2************");
            rs = s.executeQuery(query);
        } catch (Exception e) {
            try {
                c.rollback();
            } catch (Exception ee) {
                System.out.println("Error!");
            }
            System.out.println("Error - Database Management for tables():" + e);
        }
        return rs;
    }

    public static void closeOracleConnection() {
        try {
            c.commit();
            c.close();
        } catch (Exception e) {
            try {
                c.rollback();
            } catch (Exception ee) {
                System.out.println("Error!");
            }
            System.out.println("Error - Database Management for creting tables():" + e);
        }
    }
}
