package bankingproject;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class GUI2_Insert_Charge implements ActionListener {

    JTextField client_id2TF, number_account2TF, Type_account2TF, Balance2TF, Limit_account2TF, Type_penalties2TF, Amount_penalties2TF, Type_charge2TF, Amount_charge2TF, Type_commission2TF, Amount_commission2TF;

    double amount_charge;

    public GUI2_Insert_Charge() {
        JFrame chargeOutputframe2 = new JFrame();
        JLabel client_idL = new JLabel("Client ID:", SwingConstants.RIGHT);
        JLabel number_accountL = new JLabel("Number Account:", SwingConstants.RIGHT);
        JLabel Type_accountL = new JLabel("Type Account:", SwingConstants.RIGHT);
        JLabel Limit_accountL = new JLabel("Limit Account:", SwingConstants.RIGHT);
        JLabel Type_chargeL = new JLabel("Type Charge:", SwingConstants.RIGHT);
        JLabel Amount_chargeL = new JLabel("Amount Charge:", SwingConstants.RIGHT);
        client_id2TF = new JTextField(10);
        number_account2TF = new JTextField(10);
        Type_account2TF = new JTextField(10);
        Limit_account2TF = new JTextField(10);
        Type_charge2TF = new JTextField(10);
        Amount_charge2TF = new JTextField(10);
        JButton exitB = new JButton("Exit");
        exitB.addActionListener(this);
        JButton calculateB = new JButton("Calculate");
        calculateB.addActionListener(this);
        JButton insertB = new JButton("Save/Insert into Database");
        insertB.addActionListener(this);
        chargeOutputframe2.setTitle("CALCULATE NEW CHARGE");
        Container pane = chargeOutputframe2.getContentPane();
        pane.setLayout(new GridLayout(8, 2));
        pane.add(client_idL);
        pane.add(client_id2TF);
        pane.add(number_accountL);
        pane.add(number_account2TF);
        pane.add(Type_accountL);
        pane.add(Type_account2TF);
        pane.add(Limit_accountL);
        pane.add(Limit_account2TF);
        pane.add(Type_chargeL);
        pane.add(Type_charge2TF);
        pane.add(Amount_chargeL);
        pane.add(Amount_charge2TF);
        pane.add(calculateB);
        pane.add(insertB);
        pane.add(exitB);
        chargeOutputframe2.setSize(800, 400);
        chargeOutputframe2.setVisible(true);
    }

    public void actionPerformed(ActionEvent a) {
        if (a.getActionCommand().equals("Exit")) {
            System.exit(0);
        } else if (a.getActionCommand().equals("Calculate")) {
            double limit = Double.parseDouble(Limit_account2TF.getText());
            String Type_charge = Type_charge2TF.getText();
            if (Type_charge.contentEquals("CIP4000")) {
                amount_charge = limit * 0.005;
                Amount_charge2TF.setText(" " + amount_charge);
            } else if (Type_charge.contains("CIPL4000")) {
                amount_charge = limit * 0.005;
                Amount_charge2TF.setText(" " + amount_charge);
            } else if (Type_charge.contains("CIC4000")) {
                amount_charge = limit * 0.003;
                Amount_charge2TF.setText(" " + amount_charge);
            } else {
                amount_charge = limit * 0;
                Amount_charge2TF.setText(" " + amount_charge);
            }
        } else if (a.getActionCommand().equals("Save/Insert into Database")) {
            ConnectJavaOracle.openOracleConnection("scott", "tiger");
            String query;
            query = "INSERT INTO Account_entity";
            query = query + "(Id_client, Number_account, Type_account,Limit_account," + "Type_charge, Amount_charge)";
            query = query + "values";
            query = query + "(" + Integer.parseInt(client_id2TF.getText()) + ", " + Integer.parseInt(number_account2TF.getText()) + ", '" + Type_account2TF.getText() + "', " + Integer.parseInt(Limit_account2TF.getText()) + ", '" + Type_charge2TF.getText() + "', " + amount_charge + ")";
            System.out.println("query: " + query);
            ConnectJavaOracle.processQuery(query);
        }
    }
}
