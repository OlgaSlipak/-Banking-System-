package bankingproject;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class BankingGInterfaceCharge implements ActionListener {

    JTextField client_id1TF, number_account1TF;

    int b_Id_client;

    int b_Number_account;

    String b_Type_account = "";

    double b_Balance;

    double b_Limit_account;

    String b_Type_penalties = "";

    double b_Amount_penalties;

    String b_Type_charge = "";

    double b_Amount_charge;

    String b_Type_commission = "";

    double b_Amount_commission;

    static charge_object info_charge_obj = new charge_object();

    public BankingGInterfaceCharge() {
        JFrame chargeframe = new JFrame();
        JLabel client_idL = new JLabel("Enter Client ID:", SwingConstants.RIGHT);
        JLabel number_accountL = new JLabel("Enter Client Account:", SwingConstants.RIGHT);
        client_id1TF = new JTextField(10);
        number_account1TF = new JTextField(10);
        JButton infoB = new JButton("See Charge Type Information for All Clients FROM DATABASE");
        infoB.addActionListener(this);
        JButton searchB = new JButton("Search Charge for Client");
        searchB.addActionListener(this);
        JButton insertB = new JButton("Insert/Calculate New Charge for Client");
        insertB.addActionListener(this);
        JButton updateB = new JButton("Update Existing Charge");
        updateB.addActionListener(this);
        JButton deleteB = new JButton("Delete Existing Charge for Client");
        deleteB.addActionListener(this);
        JButton exitB = new JButton("Exit");
        exitB.addActionListener(this);
        chargeframe.setTitle("CHARGE APPLICATION");
        Container pane = chargeframe.getContentPane();
        pane.setLayout(new GridLayout(7, 2));
        pane.add(client_idL);
        pane.add(client_id1TF);
        pane.add(number_accountL);
        pane.add(number_account1TF);
        pane.add(infoB);
        pane.add(searchB);
        pane.add(insertB);
        pane.add(updateB);
        pane.add(deleteB);
        pane.add(exitB);
        chargeframe.setSize(800, 400);
        chargeframe.setVisible(true);
    }

    public void actionPerformed(ActionEvent b) {
        if (b.getActionCommand().equals("Exit")) {
            System.exit(0);
        } else if (b.getActionCommand().equals("Search Charge for Client")) {
            ConnectJavaOracle.openOracleConnection("scott", "tiger");
            String query;
            query = "Select ";
            query = query + "Id_client, Number_account, Type_account, Limit_account, Type_charge, Amount_charge";
            query = query + " from Account_entity ";
            query = query + "where Id_client = ";
            query = query + Integer.parseInt(client_id1TF.getText()) + " and Number_account = " + Integer.parseInt(number_account1TF.getText());
            System.out.println("query: " + query);
            ConnectJavaOracle.rs = ConnectJavaOracle.processSearchQuery(query);
            try {
                while (ConnectJavaOracle.rs.next()) {
                    b_Id_client = ConnectJavaOracle.rs.getInt("Id_client");
                    info_charge_obj.setId_client(b_Id_client);
                    b_Number_account = ConnectJavaOracle.rs.getInt("Number_account");
                    info_charge_obj.setNumber_account(b_Number_account);
                    b_Type_account = ConnectJavaOracle.rs.getString("Type_account");
                    info_charge_obj.setType_account(b_Type_account);
                    b_Limit_account = ConnectJavaOracle.rs.getInt("Limit_account");
                    info_charge_obj.setLimit_account(b_Limit_account);
                    b_Type_charge = ConnectJavaOracle.rs.getString("Type_charge");
                    info_charge_obj.setType_charge(b_Type_charge);
                    b_Amount_charge = ConnectJavaOracle.rs.getInt("Amount_charge");
                    info_charge_obj.setAmount_charge(b_Amount_charge);
                    System.out.println("dfgh");
                    System.out.println("Number_account: " + info_charge_obj.getNumber_account() + "\t" + info_charge_obj.getId_client() + "\t" + info_charge_obj.getType_account() + "\t" + info_charge_obj.getLimit_account() + "\t" + info_charge_obj.getType_charge() + "\t" + info_charge_obj.getAmount_charge() + "\t");
                }
            } catch (Exception e) {
                System.out.println("Error Search- " + e);
            }
            if (info_charge_obj.getId_client() > 0 && info_charge_obj.getNumber_account() > 0) {
                Output_Search_Charge output1 = new Output_Search_Charge();
                output1.client_idTF.setText(" " + info_charge_obj.getId_client());
                output1.number_accountTF.setText(" " + info_charge_obj.getNumber_account());
                output1.b_Type_accountTF.setText(" " + info_charge_obj.getType_account());
                output1.b_Limit_accountTF.setText(" " + info_charge_obj.getLimit_account());
                output1.b_Type_chargeTF.setText(" " + info_charge_obj.getType_charge());
                output1.b_Amount_chargeTF.setText(" " + info_charge_obj.getAmount_charge());
            } else {
                JOptionPane.showMessageDialog(null, "Banking Exception " + "You entered wrong input. Check please ID client and Account Number.", "Banking Exception", JOptionPane.INFORMATION_MESSAGE);
            }
        } else if (b.getActionCommand().equals("See Charge Type Information for All Clients FROM DATABASE")) {
            GUI5_See_All_Charge all_charge = new GUI5_See_All_Charge();
        } else if (b.getActionCommand().equals("Insert/Calculate New Charge for Client")) {
            GUI2_Insert_Charge charge_insert = new GUI2_Insert_Charge();
        } else if (b.getActionCommand().equals("Delete Existing Charge for Client")) {
            GUI3_Delete_charge delete_charge = new GUI3_Delete_charge();
        } else if (b.getActionCommand().equals("Update Existing Charge")) {
            GUI4_Update_charge update_charge = new GUI4_Update_charge();
        }
    }
}
