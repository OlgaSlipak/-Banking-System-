package bankingproject;

public class TestBankingProject {

    public static void main(String[] args) {
        BankingGinterface myInterface = new BankingGinterface();
    }
}
