package bankingproject;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class GUI4_Update_charge implements ActionListener {

    JTextField client_id3TF, number_account3TF, Type_account3TF, Limit_account3TF, Type_charge3TF, Amount_charge3TF;

    double amount_charge;

    public GUI4_Update_charge() {
        JFrame chargeOutputframe4 = new JFrame();
        JLabel client_idL = new JLabel("Enter Client ID:", SwingConstants.RIGHT);
        JLabel number_accountL = new JLabel("Enter Number Account:", SwingConstants.RIGHT);
        JLabel Type_accountL = new JLabel("Enter value for changing Type Account:", SwingConstants.RIGHT);
        JLabel Limit_accountL = new JLabel("Enter value for changing Limit Account:", SwingConstants.RIGHT);
        JLabel Type_chargeL = new JLabel("Enter value for changing Type Charge:", SwingConstants.RIGHT);
        JLabel Amount_chargeL = new JLabel("Amount Charge:", SwingConstants.RIGHT);
        client_id3TF = new JTextField(10);
        number_account3TF = new JTextField(10);
        Type_account3TF = new JTextField(10);
        Limit_account3TF = new JTextField(10);
        Type_charge3TF = new JTextField(10);
        Amount_charge3TF = new JTextField(10);
        JButton exitB = new JButton("Exit");
        exitB.addActionListener(this);
        JButton updateB = new JButton("UPDATE EXESTING CHARGE IN DATABASE");
        updateB.addActionListener(this);
        JButton calculateB = new JButton("CALCULATE NEW CHARGE");
        calculateB.addActionListener(this);
        chargeOutputframe4.setTitle("UPDATE EXESTING CHARGE");
        Container pane = chargeOutputframe4.getContentPane();
        pane.setLayout(new GridLayout(11, 2));
        pane.add(client_idL);
        pane.add(client_id3TF);
        pane.add(number_accountL);
        pane.add(number_account3TF);
        pane.add(Type_accountL);
        pane.add(Type_account3TF);
        pane.add(Limit_accountL);
        pane.add(Limit_account3TF);
        pane.add(Type_chargeL);
        pane.add(Type_charge3TF);
        pane.add(Amount_chargeL);
        pane.add(Amount_charge3TF);
        pane.add(calculateB);
        pane.add(updateB);
        pane.add(exitB);
        chargeOutputframe4.setSize(900, 450);
        chargeOutputframe4.setVisible(true);
    }

    public void actionPerformed(ActionEvent a) {
        if (a.getActionCommand().equals("Exit")) {
            System.exit(0);
        } else if (a.getActionCommand().equals("CALCULATE NEW CHARGE")) {
            double limit = Double.parseDouble(Limit_account3TF.getText());
            String Type_charge = Type_charge3TF.getText();
            if (Type_charge.contentEquals("CIP4000")) {
                amount_charge = limit * 0.005;
                Amount_charge3TF.setText(" " + amount_charge);
            } else if (Type_charge.contains("CIPL4000")) {
                amount_charge = limit * 0.005;
                Amount_charge3TF.setText(" " + amount_charge);
            } else if (Type_charge.contains("CIC4000")) {
                amount_charge = limit * 0.003;
                Amount_charge3TF.setText(" " + amount_charge);
            } else {
                amount_charge = limit * 0;
                Amount_charge3TF.setText(" " + amount_charge);
            }
        } else if (a.getActionCommand().equals("UPDATE EXESTING CHARGE IN DATABASE")) {
            ConnectJavaOracle.openOracleConnection("scott", "tiger");
            String query;
            query = "UPDATE Account_entity ";
            query = query + "SET Type_charge = '" + Type_charge3TF.getText() + "', Amount_charge = " + amount_charge;
            query = query + " where Id_client = ";
            query = query + Integer.parseInt(client_id3TF.getText()) + " and Number_account = " + Integer.parseInt(number_account3TF.getText());
            System.out.println("query: " + query);
            JOptionPane.showMessageDialog(null, "Banking Information " + "You UPDATED CHARGE successfully!", "Banking Information", JOptionPane.INFORMATION_MESSAGE);
            ConnectJavaOracle.processQuery(query);
        }
    }
}
