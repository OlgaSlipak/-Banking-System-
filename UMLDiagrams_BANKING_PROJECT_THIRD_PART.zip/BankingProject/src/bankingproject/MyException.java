package bankingproject;

public class MyException {
}
