package bankingproject;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class GUI6_Delete_client implements ActionListener {

    JTextField client_id3TF;

    public GUI6_Delete_client() {
        JFrame clientOutputframe3 = new JFrame();
        JLabel client_idL = new JLabel("Client ID:", SwingConstants.RIGHT);
        client_id3TF = new JTextField(10);
        JButton exitB = new JButton("Exit");
        exitB.addActionListener(this);
        JButton deleteB = new JButton("CHANGE STATUS OF CLIENT NOT ACTIVE");
        deleteB.addActionListener(this);
        clientOutputframe3.setTitle("CHANGE STATUS OF CLIENT NOT ACTIVE");
        Container pane = clientOutputframe3.getContentPane();
        pane.setLayout(new GridLayout(2, 2));
        pane.add(client_idL);
        pane.add(client_id3TF);
        pane.add(deleteB);
        pane.add(exitB);
        clientOutputframe3.setSize(650, 250);
        clientOutputframe3.setVisible(true);
    }

    public void actionPerformed(ActionEvent a) {
        if (a.getActionCommand().equals("Exit")) {
            System.exit(0);
        } else if (a.getActionCommand().equals("CHANGE STATUS OF CLIENT NOT ACTIVE")) {
            ConnectJavaOracle.openOracleConnection("scott", "tiger");
            String query;
            query = "UPDATE client_entity ";
            query = query + "SET STATUS = 'NOT ACTIVE' ";
            query = query + "where Id_client = ";
            query = query + Integer.parseInt(client_id3TF.getText());
            System.out.println("query: " + query);
            JOptionPane.showMessageDialog(null, "Banking Information " + "You CHANGED STATUS of Client NOT ACTIVE successfully!", "Banking Information", JOptionPane.INFORMATION_MESSAGE);
            ConnectJavaOracle.processQuery(query);
        }
    }
}
