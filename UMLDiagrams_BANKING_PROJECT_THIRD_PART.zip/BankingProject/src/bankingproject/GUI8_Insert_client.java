package bankingproject;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class GUI8_Insert_client implements ActionListener {

    JTextField client_id3TF, FnameTF, LnameTF, AddressTF, TelTF, E_mailTF, SSNTF;

    public GUI8_Insert_client() {
        JFrame clientOutputframe4 = new JFrame();
        JLabel client_idL = new JLabel("Enter Client ID:", SwingConstants.RIGHT);
        JLabel FnameL = new JLabel("Enter new First Name of Client:", SwingConstants.RIGHT);
        JLabel LnameL = new JLabel("Enter new Last Name of Client:", SwingConstants.RIGHT);
        JLabel AddressL = new JLabel("Enter new Address of client:", SwingConstants.RIGHT);
        JLabel TelL = new JLabel("Enter new Telephone of client:", SwingConstants.RIGHT);
        JLabel EmailL = new JLabel("Enter new E-mail of client:", SwingConstants.RIGHT);
        JLabel SSNL = new JLabel("Enter new SSN of client:", SwingConstants.RIGHT);
        client_id3TF = new JTextField(10);
        FnameTF = new JTextField(10);
        LnameTF = new JTextField(10);
        AddressTF = new JTextField(10);
        TelTF = new JTextField(10);
        E_mailTF = new JTextField(10);
        SSNTF = new JTextField(10);
        JButton exitB = new JButton("Exit");
        exitB.addActionListener(this);
        JButton updateB = new JButton("INSERT NEW CLIENT IN DATABASE");
        updateB.addActionListener(this);
        clientOutputframe4.setTitle("INSERT NEW CLIENT IN DATABASE");
        Container pane = clientOutputframe4.getContentPane();
        pane.setLayout(new GridLayout(8, 2));
        pane.add(client_idL);
        pane.add(client_id3TF);
        pane.add(FnameL);
        pane.add(FnameTF);
        pane.add(LnameL);
        pane.add(LnameTF);
        pane.add(AddressL);
        pane.add(AddressTF);
        pane.add(TelL);
        pane.add(TelTF);
        pane.add(EmailL);
        pane.add(E_mailTF);
        pane.add(SSNL);
        pane.add(SSNTF);
        pane.add(updateB);
        pane.add(exitB);
        clientOutputframe4.setSize(900, 450);
        clientOutputframe4.setVisible(true);
    }

    public void actionPerformed(ActionEvent a) {
        if (a.getActionCommand().equals("Exit")) {
            System.exit(0);
        } else if (a.getActionCommand().equals("INSERT NEW CLIENT IN DATABASE")) {
            ConnectJavaOracle.openOracleConnection("scott", "tiger");
            String query;
            query = "INSERT INTO client_entity ";
            query = query + "(Id_client, Fname, Lname, Address," + "Tel, E_mail,SSN)";
            query = query + "values";
            query = query + "(" + Integer.parseInt(client_id3TF.getText()) + ", '" + FnameTF.getText() + "', '" + LnameTF.getText() + "', '" + AddressTF.getText() + "', '" + TelTF.getText() + "', '" + E_mailTF.getText() + "', " + Integer.parseInt(SSNTF.getText()) + ")";
            System.out.println("query: " + query);
            JOptionPane.showMessageDialog(null, "Banking Information " + "You INSERT INFO of CLIENT successfully!", "Banking Information", JOptionPane.INFORMATION_MESSAGE);
            ConnectJavaOracle.processQuery(query);
        }
    }
}
